#include <stdio.h>
int main()
{
    printf("hello wordl\n");
    return 0;
}